Synthetic archive for flipturn tests.
